#!/usr/bin/env python3
"""Stage 4 corpus builder. Python 3.11+, standard library only.

Captured UTF-8 source text is supplied separately and NEVER overwritten by this script.
Run `python build_corpus.py selftest` before `python build_corpus.py build`.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import tempfile
import unicodedata
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ALPHABETS = {
    "uk": "АБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯ",
    "en": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
}
LETTER_WINDOWS = (16, 32, 256, 4096, 16384)
BYTE_BUDGETS = (0, 1, 15, 16, 17, 31, 32, 33, 256, 4096, 65536)
PG_START = re.compile(r"(?m)^\*\*\* START OF (?:THE )?PROJECT GUTENBERG EBOOK[^\n]*\*\*\*\s*$")
PG_END = re.compile(r"(?m)^\*\*\* END OF (?:THE )?PROJECT GUTENBERG EBOOK[^\n]*\*\*\*\s*$")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utf8_prefix(text: str, budget: int) -> str:
    """Largest code-point-aligned prefix at most budget bytes; never split UTF-8."""
    data = text.encode("utf-8")
    if len(data) <= budget:
        return text
    return data[:budget].decode("utf-8", errors="ignore")


def normalize(raw: bytes, kind: str) -> str:
    text = raw.decode("utf-8-sig", errors="strict")
    if "<html" in text[:1000].lower() or "<!doctype" in text[:1000].lower():
        raise ValueError("Замість TXT отримано HTML; збережіть експорт у plain text")
    if kind == "gutenberg":
        start = PG_START.search(text)
        end = PG_END.search(text)
        if start is None or end is None or end.start() <= start.end():
            raise ValueError("Немає очікуваних маркерів START/END Project Gutenberg")
        text = text[start.end():end.start()]
    elif kind != "wikisource_dom":
        raise ValueError(f"Невідомий формат: {kind}")
    # No transliteration, spelling correction, word reflow, or punctuation removal.
    return unicodedata.normalize("NFC", text.replace("\r\n", "\n").replace("\r", "\n")).strip() + "\n"


def classic(text: str, language: str) -> tuple[str, dict]:
    alphabet = set(ALPHABETS[language])
    emitted = []
    outside = Counter()
    for char in text:
        upper = char.upper()
        if len(upper) == 1 and upper in alphabet:
            emitted.append(upper)
        elif char.isalpha():
            outside[char] += 1
    total_alpha = len(emitted) + sum(outside.values())
    stats = {
        "alphabet": ALPHABETS[language],
        "eligible_letters": len(emitted),
        "outside_alphabet_letters": sum(outside.values()),
        "outside_alphabet_ratio": round(sum(outside.values()) / total_alpha, 6) if total_alpha else 0,
        "outside_alphabet_examples": outside.most_common(20),
        "punctuation_spaces_digits_removed": "yes; not counted as letters",
    }
    return "".join(emitted), stats


def put_bytes(base: Path, relative: str, data: bytes, record: list, origin: str, **extra) -> None:
    target = base / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    record.append({"path": relative, "origin": origin, "bytes": len(data), "sha256": digest(data), **extra})


def put_text(base: Path, relative: str, content: str, record: list, origin: str, **extra) -> None:
    put_bytes(base, relative, content.encode("utf-8"), record, origin,
              codepoints=len(content), utf8_valid=True, **extra)


def windows(content: str, length: int) -> dict[str, tuple[int, str]]:
    if len(content) < length:
        return {}
    return {
        "head": (0, content[:length]),
        "middle": ((len(content) - length) // 2,
                   content[(len(content) - length) // 2:(len(content) - length) // 2 + length]),
        "tail": (len(content) - length, content[-length:]),
    }


def build(root: Path, spec_file: Path, output: Path) -> dict:
    spec = json.loads(spec_file.read_text(encoding="utf-8"))
    output.mkdir(parents=True, exist_ok=True)
    entries: list[dict] = []
    records: list[dict] = []
    prepared: dict[str, str] = {}
    missing = [item["raw_file"] for item in spec["sources"] if not (root / item["raw_file"]).is_file()]
    if missing:
        raise FileNotFoundError("Бракує оригіналів: " + ", ".join(missing))

    for item in spec["sources"]:
        language = item["language"]
        raw_path = root / item["raw_file"]
        raw = raw_path.read_bytes()
        if len(raw) < item["minimum_bytes"]:
            raise ValueError(f"{item['id']}: файл замалий ({len(raw)} < {item['minimum_bytes']} байтів)")
        clean = normalize(raw, item["kind"])
        if len(clean) < item["minimum_bytes"] // 3:
            raise ValueError(f"{item['id']}: після очищення текст підозріло малий")
        letters, stats = classic(clean, language)
        if not letters:
            raise ValueError(f"{item['id']}: нема літер цільової абетки")
        origin = item["id"]
        prefix = f"derived/{origin}"
        put_text(output, f"{prefix}/text_utf8.txt", clean, records, origin, view="text_nfc_lf")
        put_text(output, f"{prefix}/letters.txt", letters, records, origin, view="classic_letters")
        for length in LETTER_WINDOWS:
            for location, (offset, chunk) in windows(letters, length).items():
                put_text(output, f"{prefix}/letters_{length}_{location}.txt", chunk, records, origin,
                         view="classic_window", start_codepoint=offset, target_letters=length)
        # Byte budgets are upper bounds: the actual byte count can differ across alphabets.
        for budget in BYTE_BUDGETS:
            head = utf8_prefix(clean, budget)
            put_text(output, f"{prefix}/utf8_at_most_{budget}.bin", head, records, origin,
                     view="utf8_budget", byte_budget=budget)
        for length in (16, 256):
            chunk = utf8_prefix(clean, length)
            put_text(output, f"{prefix}/hex_view_{length}.hex", chunk.encode("utf-8").hex(), records,
                     origin, view="hex_display_only", source_actual_bytes=len(chunk.encode("utf-8")))
        prepared[origin] = clean
        entries.append({
            "id": origin,
            "language": language,
            "genre": item["genre"],
            "title": item["title"],
            "edition": item["edition"],
            "catalog": item["catalog"],
            "catalog_revision": item.get("catalog_revision"),
            "acquisition": item["acquisition"],
            "rights_note": item["rights"],
            "raw_file": item["raw_file"],
            "raw_bytes": len(raw),
            "raw_sha256": digest(raw),
            "nfc_lf_codepoints": len(clean),
            "nfc_lf_utf8_bytes": len(clean.encode("utf-8")),
            "newlines": clean.count("\n"),
            "classic": stats,
        })

    # These are control inputs, not specimens of natural language.
    controls = {
        "zero_4096.bin": bytes(4096),
        "repeated_4096.bin": bytes([0x41]) * 4096,
        "incrementing_4096.bin": bytes(range(256)) * 16,
        "mixed_uk_en_utf8.bin": (utf8_prefix(prepared["uk_nechui_1879"], 2048)
                                 + "\n|0123456789|\n"
                                 + utf8_prefix(prepared["en_austen_1342"], 2048)).encode("utf-8"),
    }
    for filename, blob in controls.items():
        put_bytes(output, f"controls/{filename}", blob, records, "constructed_control",
                  utf8_valid=(filename == "mixed_uk_en_utf8.bin"), view="control")

    manifest = {
        "schema": 1,
        "transform": "NFC + LF + Gutenberg markers (if applicable); uppercase then retain only explicitly listed alphabet for classical lane",
        "implementation": {"python": sys.version.split()[0], "unicode_database": unicodedata.unidata_version,
                           "script_sha256": digest(Path(__file__).read_bytes()),
                           "source_spec_sha256": digest(spec_file.read_bytes())},
        "originals": entries,
        "artifacts": records,
        "metric_note": "codepoints != graphemes != letters != UTF-8 bytes; no grapheme counting claimed",
        "status": "generated from four captured source texts",
    }
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def selftest() -> None:
    assert len(ALPHABETS["uk"]) == 33 and len(ALPHABETS["en"]) == 26
    assert utf8_prefix("іЇA", 1) == ""
    assert utf8_prefix("іЇA", 2) == "і"
    assert utf8_prefix("іЇA", 5) == "іЇA"
    assert normalize(b"A\r\nB", "wikisource_dom") == "A\nB\n"
    assert normalize("e\u0301".encode("utf-8"), "wikisource_dom") == "é\n"
    assert normalize(b"*** START OF THE PROJECT GUTENBERG EBOOK T ***\nX\n*** END OF THE PROJECT GUTENBERG EBOOK T ***", "gutenberg") == "X\n"
    assert classic("Ґ ґ Є ї I і ё ’ 123", "uk")[0] == "ҐҐЄЇІ"
    assert classic("Aa Zz ß I", "en")[0] == "AAZZI"
    with tempfile.TemporaryDirectory() as folder:
        base = Path(folder)
        (base / "raw").mkdir()
        (base / "raw/test.txt").write_text("Ї ї A +123", encoding="utf-8")
        (base / "spec.json").write_text(json.dumps({"sources": [{"id": "test", "language": "uk", "genre": "test", "title": "test", "edition": "test", "catalog": "test", "raw_file": "raw/test.txt", "kind": "wikisource_dom", "minimum_bytes": 1}]}), encoding="utf-8")
        # Full build assumes four particular corpus IDs for mixed controls; test primitives above only.
        assert digest((base / "raw/test.txt").read_bytes())
    print("selftest: OK (UTF-8 bounds, 33/26 alphabets, source markers, NFC/LF)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("selftest", "build"))
    args = parser.parse_args()
    if args.command == "selftest":
        selftest()
    else:
        manifest = build(ROOT, ROOT / "sources.json", ROOT / "output")
        print(f"Build: {len(manifest['originals'])} originals; {len(manifest['artifacts'])} derived artifacts")


if __name__ == "__main__":
    main()
